StudyBuddy — Cloudflare Pages deployment

This is a static website. No build command or backend is required.

Deploy: Cloudflare Dashboard > Workers & Pages > Create > Pages > Upload assets (Direct Upload). Upload the index.html file or a ZIP containing index.html at the ZIP root.

Important: this version uses browser localStorage for demo login and progress. It does not create real accounts or sync progress between devices.
